#ifndef INCLUDE_ARCHIVOS_H_
#define INCLUDE_ARCHIVOS_H_


#include <commons/collections/queue.h>
#include <commons/config.h>
#include <commons/string.h>
#include <commons/collections/dictionary.h>
#include <pthread.h>
#include <semaphore.h>
#include "../../Shared/include/estructuras_compartidas.h"
#include "../../Shared/include/logs.h"
#include "utils.h" //I cant believe what Im seeing *dies of cringe


//-----------------------ESTRUCTURAS------------------------------------------------------------------------

//-----------------------FUNCIONES------------------------------------------------------------------------




#endif /* INCLUDE_ARCHIVOS_H_ */