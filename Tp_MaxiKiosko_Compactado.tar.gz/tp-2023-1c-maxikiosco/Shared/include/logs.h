#ifndef INCLUDE_LOGS_H_
#define INCLUDE_LOGS_H_

#include <commons/log.h>

extern t_log* logger;
t_log* iniciar_logger(char*,char*);


#endif
