#ifndef INCLUDE_CONFIG_H_
#define INCLUDE_CONFIG_H_

#include <commons/config.h>
#include <commons/log.h>


t_config* iniciar_config(char*);

#endif
