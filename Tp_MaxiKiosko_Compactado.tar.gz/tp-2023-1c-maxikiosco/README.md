# tp-2023-1c-maxikiosco
##Comando para valgrind:
valgrind --leak-check=full --track-origins=yes --log-file=valgrind.log <./NombreDelArchivo.exe>
valgrind --tool=helgrind --log-file=helgrind.log <./programa>

LISTA DE HANDSHAKES:
1) Kernel
2) Memoria
3) Filesystem
4) cpu
5) consola
