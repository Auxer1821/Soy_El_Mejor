#ifndef CONSOLA_H_
#define CONSOLA_H_

#include "../../Shared/include/logs.h"
#include "../../Shared/include/cliente.h"
#include "../../Shared/include/config.h"

#include "../../Shared/include/estructuras_compartidas.h"


#include<stdio.h>
#include<stdlib.h>

#include "utils.h"

#include<commons/string.h>
#include<commons/collections/list.h>




#endif /* CONSOLA_H_ */
