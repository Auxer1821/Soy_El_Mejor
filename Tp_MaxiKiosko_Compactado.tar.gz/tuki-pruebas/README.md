# TUKI - Pruebas

Dentro de este repositorio encontraran los archivos de scripts para realizar las pruebas del TP. 
El enunciado de las pruebas lo pueden encontrar en el siguiente [link](https://docs.google.com/document/d/1MNalaTCB95qGO8q3rlR7VVCQqv3VLP3oeYxBgXgBy5g)

Los scripts deben estar correctos, cualquier inconveniente o error de redacción en los mismos por favor crear un issue en el [foro](https://faq.utnso.com.ar/foro)